
import __ASTRO_IMAGE_IMPORT_ZDCOOb from "../../assets/AT-AT.png?astroContentImageFlag=&importer=src%2Fcontent%2Fdocs%2Findex.mdx";
export default new Map([["../../assets/AT-AT.png?astroContentImageFlag=&importer=src%2Fcontent%2Fdocs%2Findex.mdx", __ASTRO_IMAGE_IMPORT_ZDCOOb]]);
		